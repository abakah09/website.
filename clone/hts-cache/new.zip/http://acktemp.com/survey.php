<!DOCTYPE html>
<!-- saved from url=(0047)http://getbootstrap.com/examples/justified-nav/ -->
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="description" content="Our service technicians are EPA certified and actively involved in continuing HVAC-R education to keep up with the newest technologies. Servicing the commercial, industrial, and institutional fields. We are factory certified Desert Aire representatives. Serving the Chicagoland area & suburbs since 1980. Please feel free to call us for all of your heating ventilation, air conditioning dehumidification, plumbing & refrigeration needs.">
<meta name="author" content="">
<link rel="icon" href="favicon.ico">
<title>Ack-Temp Mechanical Services Inc.</title>

<!-- Bootstrap core CSS -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">

<!-- Custom styles for this template -->
<link href="css/justified-nav.css" rel="stylesheet" type="text/css">

<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="js/ie-emulation-modes-warning.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500,700,300,300italic,400italic,500italic,700italic' rel='stylesheet' type='text/css'>
<style type="text/css">
.container .row.clearfix .col-lg-8 h4 {
	margin-top: 30px;
}
.container .row.clearfix .col-lg-8 .form-wrap form .table.table-striped tr td p {
	text-align: left;
}
</style>
<link type="text/css" rel="stylesheet" href="//www.demandforce.com/widget/css/widget.css" />
</head>

<body>
<div id="topbar" class="container-fluid">
  <div class="container">
  
   <div class="row clearfix">
 	<div class="col-lg-6" id="logo"><a href="index.php"><img src="img/logo-sm.png" class="img-responsive"></a></div>
	<div class="col-lg-6">
	  <h2 class="pull-right">847-719-COOL (2665)</h2>
	</div>
  </div>
  
    <nav class="navbar navbar-inverse" style="padding-bottom:0px;margin-bottom:0px">
      <div class="container-fluid"> 
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav pull-right">
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Products &amp; Services <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="tuneups.php">Precision Tune-up</a></li>
                <li><a href="manufacturers.php">Manufacturers Products</a></li>
                <li><a href="24-hour-service.php">24-Hour Service</a></li>
                <li><a href="preventative-maintenance.php">Preventative Maintenance Plans</a></li>
                <li><a href="humidifiers.php">Humidifiers</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Commercial <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="commercial.php">Commercial Installation Design & Build</a></li>
                <li><a href="commercial-hvac.php">Commercial HVAC Repair & Maintenance</a></li>
                <li><a href="mechanical-demolition.php">Mechanical Demolition</a></li>
                <li><a href="refrigeration.php">Refrigeration</a></li>
                <li><a href="dehumidification.php">Dehumidification Systems</a></li>
                <li><a href="welding.php">Welding and Fabrication</a></li>
                <li><a href="plumbing.php">Plumbing</a></li>
                <li><a href="piping.php">Piping</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Residential <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="residentall-hvac.php">New Construction</a></li>
                <li><a href="remodel.php">Remodel</a></li>
                <li><a href="repair.php">Repair</a></li>
              </ul>
            </li>
            <li><a href="promotions.php">Promotions</a></li>
            <li><a href="faq.php">FAQ</a></li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About Us <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="company.php">Ack-Temp</a></li>
                <li><a href="community.php">Community Involvement</a></li>
                <li><a href="comments.php">Customer Comments</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Contact Us <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="location.php">Contact Information</a></li>
                <li><a href="employment.php">Employment</a></li>
                <li><a href="contact.php">Contact Form</a></li>
                <li><a href="survey.php">Satisfaction Survey</a></li>
                <li><a href="appointment.php">Schedule Appointment</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- /.navbar-collapse --> 
      </div>
      <!-- /.container-fluid --> 
    </nav>
  </div></div>
<div class="container" style="margin-top:30px"> 
  
  <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. --> 
  <!-- Jumbotron --><!-- Example row of columns -->
  <div class="row clearfix">
    <div class="col-lg-8">
        <h2 style="margin-top:0px"><strong>Please take amoment and rate our service</strong></h2>
        <p style="margin-top:0px">(5 = Highly Satisfied, 1 = Not Satisfied)</p>
        <div class="form-wrap" style="clear:left">
          <form method="post" action="formmail.php" name="SampleForm">
            <input type="hidden" name="env_report" value="REMOTE_HOST,REMOTE_ADDR,HTTP_USER_AGENT,AUTH_TYPE,REMOTE_USER" />
            <!-- STEP 2: Put your email address in the 'recipients' value.
                 Note that you also have to allow this email address in the
                 $TARGET_EMAIL setting within formmail.php!
    -->
            <input type="hidden" name="recipients" value="mail@acktemp.com" />
            <!-- STEP 3: Specify required fields in the 'required' value - or leave unchanged.
            NOTE: DO NOT put your email address and name here.
            "Your email address" and "Your name" are error messages for your users to see,
            not placeholders for you to replace.
    -->
            <input type="hidden" name="required" value="EmailAddr:Your email address,FullName:Your name" />
            <!-- STEP 4: Put your subject line in the 'subject' value. -->
            <input type="hidden" name="subject" value="Contact message from acktemp.com" />
            <!-- ALL DONE! Visit our site for HOW TO guides and more complex features. -->
            <!-- this derives (creates) "email" and "realname" special fields from the input fields -->
            <input type="hidden" name="derive_fields" value="email=EmailAddr,realname=FullName" />
            <!-- this excludes the "email" and "realname" special fields from the body of the email you receive -->
            <input type="hidden" name="mail_options" value="Exclude=email;realname" />
            <input type="hidden" name="good_url" value="thanks.php" />
            Please enter your name:<br>
  <input name="FullName" type="text" class="form-control" />
  <br>
  <br>
            Please enter your email address:<br>
  <input name="EmailAddr" type="text" class="form-control" />
  <br>
  <table class="table table-striped table-bordered table-hover" width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="left" valign="top"><p>Were you satisfied with the ease of scheduling an appointment?</p></td>
      <td width="60" align="center" valign="top">
        <label>
          <input type="radio" name="Scheduling: " value="5" id="RadioGroup1_0">
          5</label>
      </td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Scheduling: " value="4" id="RadioGroup1_1">
        4</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Scheduling: " value="3" id="RadioGroup1_2">
        3</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Scheduling: " value="2" id="RadioGroup1_3">
        2</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Scheduling: " value="1" id="RadioGroup1_4">
        1</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Scheduling: " value="N/A" id="RadioGroup1_5">
        N/A</label></td>
    </tr>
    <tr>
      <td align="left" valign="top"><p>Did we serve you in a friendly manner?</p></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Friendliness: " value="5" id="RadioGroup2_0">
        5</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Friendliness: " value="4" id="RadioGroup2_1">
        4</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Friendliness: " value="3" id="RadioGroup2_2">
        3</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Friendliness: " value="2" id="RadioGroup2_3">
        2</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Friendliness: " value="1" id="RadioGroup2_4">
        1</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Friendliness: " value="N/A" id="RadioGroup2_5">
        N/A</label></td>
      </tr>
    <tr>
      <td align="left" valign="top"><p>Did we perform to your satisfaction?</p></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Performance: " value="5" id="RadioGroup3_0">
        5</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Performance: " value="4" id="RadioGroup3_1">
        4</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Performance: " value="3" id="RadioGroup3_2">
        3</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Performance: " value="2" id="RadioGroup3_3">
        2</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Performance: " value="1" id="RadioGroup3_4">
        1</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Performance: " value="N/A" id="RadioGroup3_5">
        N/A</label></td>
      </tr>
    <tr>
      <td align="left" valign="top"><p>Did we serve you in a timely manner?</p></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Timeliness: " value="3" id="RadioGroup4_0">
        5</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Timeliness: " value="4" id="RadioGroup4_1">
        4</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Timeliness: " value="3" id="RadioGroup4_2">
        3</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Timeliness: " value="2" id="RadioGroup4_3">
        2</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Timeliness: " value="1" id="RadioGroup4_4">
        1</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Timeliness: " value="N/A" id="RadioGroup4_5">
        N/A</label></td>
      </tr>
    <tr>
      <td align="left" valign="top"><p>Were you satisfied with the explanation of services, products, and/ or charges?</p></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Communication: " value="5" id="RadioGroup5_0">
        5</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Communication: " value="4" id="RadioGroup5_1">
        4</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Communication: " value="3" id="RadioGroup5_2">
        3</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Communication: " value="2" id="RadioGroup5_3">
        2</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Communication: " value="1" id="RadioGroup5_4">
        1</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Communication: " value="N/A" id="RadioGroup5_5">
        N/A</label></td>
      </tr>
    <tr>
      <td align="left" valign="top"><p>How would you rate our cleanliness?</p></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Cleanliness: " value="5" id="RadioGroup6_0">
        5</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Cleanliness: " value="4" id="RadioGroup6_1">
        4</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Cleanliness: " value="3" id="RadioGroup6_2">
        3</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Cleanliness: " value="2" id="RadioGroup6_3">
        2</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Cleanliness: " value="1" id="RadioGroup6_4">
        1</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Cleanliness: " value="N/A" id="RadioGroup6_5">
        N/A</label></td>
      </tr>
    <tr>
      <td align="left" valign="top"><p>How would you rate the quality of our service?</p></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Quality: " value="5" id="RadioGroup7_0">
        5</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Quality: " value="4" id="RadioGroup7_1">
        4</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Quality: " value="3" id="RadioGroup7_2">
        3</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Quality: " value="2" id="RadioGroup7_3">
        2</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Quality: " value="1" id="RadioGroup7_4">
        1</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Quality: " value="N/A" id="RadioGroup7_5">
        N/A</label></td>
      </tr>
    <tr>
      <td align="left" valign="top"><p>How would you rate your overall experience?</p></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Overall: " value="5" id="RadioGroup8_0">
        5</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Overall: " value="4" id="RadioGroup8_1">
        4</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Overall: " value="3" id="RadioGroup8_2">
        3</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Overall: " value="2" id="RadioGroup8_3">
        2</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Overall: " value="1" id="RadioGroup8_4">
        1</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Overall: " value="N/A" id="RadioGroup8_5">
        N/A</label></td>
      </tr>
    <tr>
      <td align="left" valign="top"><p>Would you return to our business in the future?</p></td>
      <td width="60" align="center" valign="top">
        <label>
          <input type="radio" name="Return: " value="Yes" id="RadioGroup9_0">
          Yes</label>
      </td>
      <td width="60" align="center" valign="top"><label>
          <input type="radio" name="Return: " value="No" id="RadioGroup9_1">
          No</label></td>
      <td width="60" align="center" valign="top">&nbsp;</td>
      <td width="60" align="center" valign="top">&nbsp;</td>
      <td width="60" align="center" valign="top">&nbsp;</td>
      <td width="60" align="center" valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td align="left" valign="top"><p>Would you refer a friend to our business?</p></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Refer: " value="Yes" id="RadioGroup10_0">
        Yes</label></td>
      <td width="60" align="center" valign="top"><label>
        <input type="radio" name="Refer: " value="No" id="RadioGroup10_1">
        No</label></td>
      <td width="60" align="center" valign="top">&nbsp;</td>
      <td width="60" align="center" valign="top">&nbsp;</td>
      <td width="60" align="center" valign="top">&nbsp;</td>
      <td width="60" align="center" valign="top">&nbsp;</td>
    </tr>
  </table>
  <br>
            Additional Comments::<br>
  <textarea name="mesg" cols="50" rows="10" class="form-control"></textarea>
  <br>
  <br>
  <br>
  <input type="submit" class="btn btn-primary btn-lg" value="Send" />
  <br>
  <br>
          </form>
        </div>
      <br>
      </p>
      <h4><br>
        </h4>
<div class="panel panel-default">
      </div>
        <div class="row clearfix"></div>
    </div>
         
          
      
     
      
     <div class="col-lg-3 col-lg-push-1">
        <div class="panel panel-primary">
          <div class="panel-heading">Online Scheduling & More</div>
          <div class="panel-body">
          <p> <img src="img/btn-go.png" name="scheduler_tile" align="left" id="scheduler_tile_l" style="cursor: pointer;"  onclick="javascript:window.open('//www.demandforced3.com/b/etile_scheduler_popup.jsp?d3cp_exid=acktempmechanicalservicesinc&d3cp_source=My%20Website','newwindow', 'width=790px, top=0, left=0, toolbar=no, menubar=no, scrollbars=1, resizable=1, location=no, status=0');" />All requests will be answered within one hour during business hours or by 9:00 a.m. on the next business day.</p>
  </div>
        </div>        <div class="panel panel-primary">
         <div class="panel-heading">Free Quotes and Estimates </div>
         <div class="panel-body"> Get a free quick quote or estimate anytime you have a heating or cooling need.
           <p></p>
           <p><img src="img/panel-img-sm-quote.jpg" class="img-responsive" alt="img"></p>
         </div>
         <div class="panel-footer"><a href="quotes-and-estimates.php" class="btn btn-primary" > Learn More</a></div>
       </div>        <div class="panel panel-primary">
         <div class="panel-heading">Customer Comments</div>
         <div class="panel-body">
           <p>
			Prompt, efficient, knowledgable. Thank you for your review and survey. It is much appreciated.<br><br>—Anonymous<br>           </p>
         </div>
         <div class="panel-footer"><a href="comments.php" class="btn btn-default" > See All Comments</a></div>
       </div>

    </div>
  </div>
  
<!-- Site footer --></div>
<footer class="footer clearfix">
  <div class="container">
  	<div class="col-lg-4">
    <p><img src="img/logo-sm.png" width="286" height="54"></p>
    <p>805 OAKWOOD RD. SUITE B <br>
      LAKE ZURICH, ILLINOIS 60047</p>
    <p><strong style="font-size: 18px">847-719-2665</strong></p>
    <p>&nbsp;</p>
    <p>© Ack-Temp Mechanical Services Inc. 2024</p>
  	</div>
    <div class="col-lg-4"><p></p></div>
    <div class="col-lg-4"><p class="pull-right" style="margin-top:180px" >Site created by <a href="http://www.bizazz.com" target="_blank"><img src="img/logo-bizazz.png" width="80" alt="bizazz logo" /></a></p>
    <p></p></div>
  </div>
</footer><!-- /container --> 

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug --> 
<script src="js/ie10-viewport-bug-workaround.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<!-- Latest compiled and minified JavaScript --> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>