<!DOCTYPE html>
<!-- saved from url=(0047)http://getbootstrap.com/examples/justified-nav/ -->
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="description" content="Our service technicians are EPA certified and actively involved in continuing HVAC-R education to keep up with the newest technologies. Servicing the commercial, industrial, and institutional fields. We are factory certified Desert Aire representatives. Serving the Chicagoland area & suburbs since 1980. Please feel free to call us for all of your heating ventilation, air conditioning dehumidification, plumbing & refrigeration needs.">
<meta name="author" content="">
<link rel="icon" href="favicon.ico">
<title>Ack-Temp Mechanical Services Inc.</title>

<!-- Bootstrap core CSS -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">

<!-- Custom styles for this template -->
<link href="css/justified-nav.css" rel="stylesheet" type="text/css">

<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="js/ie-emulation-modes-warning.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500,700,300,300italic,400italic,500italic,700italic' rel='stylesheet' type='text/css'>
</head>

<body>
<div id="topbar" class="container-fluid">
  <div class="container">
  
   <div class="row clearfix">
 	<div class="col-lg-6" id="logo"><a href="index.php"><img src="img/logo-sm.png" class="img-responsive"></a></div>
	<div class="col-lg-6">
	  <h2 class="pull-right">847-719-COOL (2665)</h2>
	</div>
  </div>
  
    <nav class="navbar navbar-inverse" style="padding-bottom:0px;margin-bottom:0px">
      <div class="container-fluid"> 
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav pull-right">
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Products &amp; Services <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="tuneups.php">Precision Tune-up</a></li>
                <li><a href="manufacturers.php">Manufacturers Products</a></li>
                <li><a href="24-hour-service.php">24-Hour Service</a></li>
                <li><a href="preventative-maintenance.php">Preventative Maintenance Plans</a></li>
                <li><a href="humidifiers.php">Humidifiers</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Commercial <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="commercial.php">Commercial Installation Design & Build</a></li>
                <li><a href="commercial-hvac.php">Commercial HVAC Repair & Maintenance</a></li>
                <li><a href="mechanical-demolition.php">Mechanical Demolition</a></li>
                <li><a href="refrigeration.php">Refrigeration</a></li>
                <li><a href="dehumidification.php">Dehumidification Systems</a></li>
                <li><a href="welding.php">Welding and Fabrication</a></li>
                <li><a href="plumbing.php">Plumbing</a></li>
                <li><a href="piping.php">Piping</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Residential <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="residentall-hvac.php">New Construction</a></li>
                <li><a href="remodel.php">Remodel</a></li>
                <li><a href="repair.php">Repair</a></li>
              </ul>
            </li>
            <li><a href="promotions.php">Promotions</a></li>
            <li><a href="faq.php">FAQ</a></li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About Us <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="company.php">Ack-Temp</a></li>
                <li><a href="community.php">Community Involvement</a></li>
                <li><a href="comments.php">Customer Comments</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Contact Us <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="location.php">Contact Information</a></li>
                <li><a href="employment.php">Employment</a></li>
                <li><a href="contact.php">Contact Form</a></li>
                <li><a href="survey.php">Satisfaction Survey</a></li>
                <li><a href="appointment.php">Schedule Appointment</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- /.navbar-collapse --> 
      </div>
      <!-- /.container-fluid --> 
    </nav>
  </div></div>
<div class="container" style="margin-top:30px"> 
  
  <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. --> 
  <!-- Jumbotron --><!-- Example row of columns -->
  <div class="row clearfix">
    <div class="col-lg-8">
        <h1 style="margin-top:0px"><strong>&nbsp;Plumbing</strong></h1>
        <p style="margin-top:0px">
          <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
          <HTML>
          <!--  		@page { margin: 0.79in }  		H1 { margin-top: 0.07in; margin-bottom: 0.07in; line-height: 100%; page-break-after: auto }  		H1.western { font-family: "Times New Roman", serif }  		H1.cjk { font-family: "Times New Roman" }  		H1.ctl { font-family: "Times New Roman" }  		P { margin-bottom: 0.08in }  	-->
          <BODY DIR="LTR">
        </p>
      <hr>
        <h4><img src="img/plumbing-cover.jpg" alt="" width="330" height="429" align="left"></h4>
        <ul>
          <li>
          <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">Complete Building Analysis</li>
          <li>New Construction</li>
          <li>Remodel and Retro Fit</li>
          <li>Design Build</li>
          <li>Roof Drain and Storm Water Piping</li>
          <li>Underground Site Work</li>
          <li>Sewer and Water</li>
          <li>EPA Certified Backflow Testing    </li>
      </ul>
    </div>
   <div class="col-lg-3 col-lg-push-1">
        <div class="panel panel-primary">
          <div class="panel-heading">Online Scheduling & More</div>
          <div class="panel-body">
          <p> <img src="img/btn-go.png" name="scheduler_tile" align="left" id="scheduler_tile_l" style="cursor: pointer;"  onclick="javascript:window.open('//www.demandforced3.com/b/etile_scheduler_popup.jsp?d3cp_exid=acktempmechanicalservicesinc&d3cp_source=My%20Website','newwindow', 'width=790px, top=0, left=0, toolbar=no, menubar=no, scrollbars=1, resizable=1, location=no, status=0');" />All requests will be answered within one hour during business hours or by 9:00 a.m. on the next business day.</p>
  </div>
        </div>        <div class="panel panel-primary">
         <div class="panel-heading">Free Quotes and Estimates </div>
         <div class="panel-body"> Get a free quick quote or estimate anytime you have a heating or cooling need.
           <p></p>
           <p><img src="img/panel-img-sm-quote.jpg" class="img-responsive" alt="img"></p>
         </div>
         <div class="panel-footer"><a href="quotes-and-estimates.php" class="btn btn-primary" > Learn More</a></div>
       </div>        <div class="panel panel-primary">
         <div class="panel-heading">Customer Comments</div>
         <div class="panel-body">
           <p>
			I've been using Ack-Temp for the last 15years. Russ and everyone have always done an excellent Job on whatever project I throw at them. I've become good friends with Russ over these years and I wouldn't trade him for anyone! ...MoreI've been using Ack-Temp for the last 15years. Russ and everyone have always done an excellent Job on whatever project I throw at them. I've become good friends with Russ over these years and I wouldn't trade him for anyone!<br><br>
				—David,<br>Owner of Tortorices Pizzeria<br>Downers Grove IL<br>           </p>
         </div>
         <div class="panel-footer"><a href="comments.php" class="btn btn-default" > See All Comments</a></div>
       </div>

    </div>
  </div>
  
<!-- Site footer --></div>
<footer class="footer clearfix">
  <div class="container">
  	<div class="col-lg-4">
    <p><img src="img/logo-sm.png" width="286" height="54"></p>
    <p>805 OAKWOOD RD. SUITE B <br>
      LAKE ZURICH, ILLINOIS 60047</p>
    <p><strong style="font-size: 18px">847-719-2665</strong></p>
    <p>&nbsp;</p>
    <p>© Ack-Temp Mechanical Services Inc. 2024</p>
  	</div>
    <div class="col-lg-4"><p></p></div>
    <div class="col-lg-4"><p class="pull-right" style="margin-top:180px" >Site created by <a href="http://www.bizazz.com" target="_blank"><img src="img/logo-bizazz.png" width="80" alt="bizazz logo" /></a></p>
    <p></p></div>
  </div>
</footer><!-- /container --> 

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug --> 
<script src="js/ie10-viewport-bug-workaround.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<!-- Latest compiled and minified JavaScript --> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>