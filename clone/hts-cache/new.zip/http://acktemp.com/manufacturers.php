<!DOCTYPE html>
<!-- saved from url=(0047)http://getbootstrap.com/examples/justified-nav/ -->
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="description" content="Our service technicians are EPA certified and actively involved in continuing HVAC-R education to keep up with the newest technologies. Servicing the commercial, industrial, and institutional fields. We are factory certified Desert Aire representatives. Serving the Chicagoland area & suburbs since 1980. Please feel free to call us for all of your heating ventilation, air conditioning dehumidification, plumbing & refrigeration needs.">
<meta name="author" content="">
<link rel="icon" href="favicon.ico">
<title>Ack-Temp Mechanical Services Inc.</title>

<!-- Bootstrap core CSS -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">

<!-- Custom styles for this template -->
<link href="css/justified-nav.css" rel="stylesheet" type="text/css">

<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="js/ie-emulation-modes-warning.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500,700,300,300italic,400italic,500italic,700italic' rel='stylesheet' type='text/css'>
</head>

<body>
<div id="topbar" class="container-fluid">
  <div class="container">
  
   <div class="row clearfix">
 	<div class="col-lg-6" id="logo"><a href="index.php"><img src="img/logo-sm.png" class="img-responsive"></a></div>
	<div class="col-lg-6">
	  <h2 class="pull-right">847-719-COOL (2665)</h2>
	</div>
  </div>
  
    <nav class="navbar navbar-inverse" style="padding-bottom:0px;margin-bottom:0px">
      <div class="container-fluid"> 
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav pull-right">
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Products &amp; Services <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="tuneups.php">Precision Tune-up</a></li>
                <li><a href="manufacturers.php">Manufacturers Products</a></li>
                <li><a href="24-hour-service.php">24-Hour Service</a></li>
                <li><a href="preventative-maintenance.php">Preventative Maintenance Plans</a></li>
                <li><a href="humidifiers.php">Humidifiers</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Commercial <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="commercial.php">Commercial Installation Design & Build</a></li>
                <li><a href="commercial-hvac.php">Commercial HVAC Repair & Maintenance</a></li>
                <li><a href="mechanical-demolition.php">Mechanical Demolition</a></li>
                <li><a href="refrigeration.php">Refrigeration</a></li>
                <li><a href="dehumidification.php">Dehumidification Systems</a></li>
                <li><a href="welding.php">Welding and Fabrication</a></li>
                <li><a href="plumbing.php">Plumbing</a></li>
                <li><a href="piping.php">Piping</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Residential <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="residentall-hvac.php">New Construction</a></li>
                <li><a href="remodel.php">Remodel</a></li>
                <li><a href="repair.php">Repair</a></li>
              </ul>
            </li>
            <li><a href="promotions.php">Promotions</a></li>
            <li><a href="faq.php">FAQ</a></li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About Us <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="company.php">Ack-Temp</a></li>
                <li><a href="community.php">Community Involvement</a></li>
                <li><a href="comments.php">Customer Comments</a></li>
              </ul>
            </li>
            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Contact Us <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="location.php">Contact Information</a></li>
                <li><a href="employment.php">Employment</a></li>
                <li><a href="contact.php">Contact Form</a></li>
                <li><a href="survey.php">Satisfaction Survey</a></li>
                <li><a href="appointment.php">Schedule Appointment</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- /.navbar-collapse --> 
      </div>
      <!-- /.container-fluid --> 
    </nav>
  </div></div>
<div class="container" style="margin-top:30px"> 
  
  <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. --> 
  <!-- Jumbotron --><!-- Example row of columns -->
  <div class="row clearfix">
    <div class="col-lg-8">
      <div class="row clearfix">
        <div class="col-md-12 icon-heading">
        <h1><img src="img/icon-manufacturers.png" alt="img" class="icons">Manufacturer's Products</h1>
        <p>Ack-Temp Mechanical Services offers high-quality heating and cooling products from many major manufacturers because we believe that our customers appreciate having a wide array of choices. </p>
        </div>
      </div>
      <p style="margin-top:0px"></p>
      <div class=""> 
        
        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#HVAC" aria-controls="home" role="tab" data-toggle="tab">HVAC</a></li>
          <li role="presentation"><a href="#Refrigeration" aria-controls="profile" role="tab" data-toggle="tab">Refrigeration</a></li>
          <li role="presentation"><a href="#Plumbing" aria-controls="messages" role="tab" data-toggle="tab">Plumbing</a></li>
        </ul>
        
        <!-- Tab panes -->
        <div class="tab-content">
          <div role="tabpanel" class="tab-pane active" id="HVAC">
            <div class="tab-container">
              <div class="col-md-3 thumbnail"><img src="logos/carrier.jpg" class="img-responsive" alt="carrier-logo"></div>
              <div class="col-md-9 description" id="description">Carrier is the world leader in high-technology heating, air-conditioning and refrigeration solutions. We have of a history of more than 100 years of proven innovation. We solve problems on a global level, and our innovations drive new industries. It is why our products and services are trusted in every corner of the world – and why you can feel good about trusting us in your corner of it.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox2"><img src="logos/trane.jpg" class="img-responsive" alt="trane-logo"></div>
              <div class="col-md-9 description" id="description2">Buildings. They’re the environments in which we live and work, learn and play, heal and grow.  And Trane makes high performance buildings better for everyone inside. Our innovative solutions create spaces that are reliable and safe, as well as healthy, comfortable and efficient – which in turn yields greater productivity and greater profitability.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox3"><img src="logos/goodman.jpg" class="img-responsive" alt="goodman-logo"></div>
              <div class="col-md-9 description" id="description3">When you choose the Goodman brand, you can rest assured that you'll receive a refreshingly affordable product that's covered by what many consider to be the best product warranties in the heating and cooling industry.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox5"><img src="logos/copeland.jpg" class="img-responsive" alt="Copeland logo"></div>
              <div class="col-md-9 description" id="description5">With reliable performance, superior efficiency, quiet operation, and diagnostic capability, Copeland Climate Technologies offers the most advanced scroll technology available to support your commercial air-conditioning needs. With the widest R-410A selection available, the Copeland Scroll™ commercial compressor offers ranges from 2–60 HP in singles and up to 80 HP in tandems.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox4"><img src="logos/rheem.jpg" class="img-responsive" alt="rheem-logo"></div>
              <div class="col-md-9 description" id="description4">Brothers Richard and Donald Rheem founded Rheem Manufacturing Company in Emeryville, Calif., in 1925. While the company has produced a number of products in its nearly 100 years of operation including steel shipping containers, household appliances like gas ranges, semi-conductors, musical instruments and more. Rheem today is the only manufacturer in the world that produces heating, cooling, water heating, pool/spa heating and commercial refrigeration products, and it is the largest manufacturer of water heating products in North America.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox6"><img src="logos/mquay.jpg" class="img-responsive" alt="McQuay-logo"></div>
              <div class="col-md-9 description" id="description6">McQuay, a Daikin company, is known worldwide for top quality HVAC solutions for almost any type of application. From small PTAC units all the way up to large chiller plants, Air Distributors can provide you with the McQuay parts you need to keep your units running and your tenants, patients, guests, empolyees, and customers happy.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox7"><img src="logos/honeywell.jpg" class="img-responsive" alt=""></div>
              <div class="col-md-9 description" id="description7">In order to increase operational and energy efficiency, you are looking for new ways to make managing your facility easier. Honeywell can successfully integrate, install and maintain building management systems and provide life cycle support for facilities like yours, making it easier to increase comfort, safety and security for your occupants.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox8"><img src="logos/tecumseh.jpg" class="img-responsive" alt=""></div>
              <div class="col-md-9 description" id="description8">Tecumseh Products Company is renowned for bringing an extra dimension of product innovation, customer reliance, and product quality to the air conditioning and refrigeration industry.  As a result of our innovative spirit and product performance, people rely on our products every day.  We literally touch the lives of millions.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox9"><img src="logos/ecobee.jpg" class="img-responsive" alt="ecobee-logo"></div>
              <div class="col-md-9 description" id="description9">At ecobee we are  focused on creating smarter wi-fi thermostats that are beautifully designed, easy to use, provide comfort and savings for families and are good for our planet.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail" id="logobox10"><img src="logos/white-rodgers.jpg" class="img-responsive" alt=""></div>
              <div class="col-md-9 description" id="description10"> With over 75 years of expertise in Heating and Cooling Controls, White-Rodgers is proud to offer a full line of furnace controls, gas valves, cooling and heat pump controls, water heater valves and controls as well as our leading edge thermostats</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 " id="logobox10"></div>
              <div class="col-md-9 description" id="description10"></div>
            </div>
          </div>
          <!-----------------------------------------------------------------------------------------------------------------------------------------
            ---------------------------------------------------------------------------------------------------------------------------------------->
          
          <div role="tabpanel" class="tab-pane" id="Refrigeration">
            <div class="tab-container ">
              <div class="col-md-3 thumbnail"><img src="logos/perlick.jpg" class="img-responsive" alt="perlick-logo"></div>
              <div class="col-md-9 description" id="description">Perlick is a national leader in total package bar and beverage systems manufacturing, including custom refrigeration equipment, custom underbar equipment, beer dispensing equipment and brewery fittings.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/mcall.jpg" class="img-responsive" alt="McCall-logo"></div>
              <div class="col-md-9 description" id="description">McCall medical commercial refrigerator and vaccine freezers as well as chromotography units, made in the USA, offers a full line of reach-in and undercounter refrigerator solutions for Schools, Universities, Correction and Health Care facilities such as hospitals, research centers and government installations.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/norlake.jpg" class="img-responsive" alt="Norlake-logo"></div>
              <div class="col-md-9 description" id="description">Nor-Lake, Incorporated is a leader in the designing and manufacturing of quality refrigeration products. With its dedication to service and a high-quality product line, Nor-Lake has earned one of the most respected names in the refrigeration industry.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/russell.jpg" class="img-responsive" alt="Russell-logo"></div>
              <div class="col-md-9 description" id="description">Russell offers everything needed in a commercial refrigeration system with over 35 basic product lines and 1000-plus models -- condensers, evaporators, condensing units, air handlers, and will pre-engineer a system to match any requirement. Since 1947 Russell has been the technology leader -- introducing new designs and new manufacturing, quality and test procedures that benefit the industry. </div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/silverking.jpg" class="img-responsive" alt="Silverking-logo"></div>
              <div class="col-md-9 description" id="description">Silver King has over 50 years of experience and expertise serving the needs of the foodservice industry. At Silver King we know what it takes to make a great piece of commercial refrigeration equipment - quality, functionality and energy efficiency. At Silver King, we understand the pressure our customers are under to keep costs down and still operate at peak efficiency..</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/tecumsehcool.jpg" class="img-responsive" alt="tecumsehcool-logo"></div>
              <div class="col-md-9 description" id="description">Innovative, durable and highly efficient products are at the heart of Tecumseh. Our products touch the lives of millions every day, driving us as a leading global manufacturer of hermetic compressors and condensing units for residential, commercial refrigeration and air conditioning applications.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/delfield.jpg" class="img-responsive" alt="Delfield-logo"></div>
              <div class="col-md-9 description" id="description">Effective pre and serve equipment - well designed to maximize space, production flow and efficiency - can turn your operation into a high-performance operation. Delfield offers a complete line up of virtually every type of prep serve equipment imaginable.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/beverage.jpg" class="img-responsive" alt="Beverage Air-logo"></div>
              <div class="col-md-9 description" id="description">Beverage-Air's portfolio of market-leading products includes glass door merchandisers, low temperature display merchandising cabinets, reach-in merchandiser coolers, under-counter coolers, worktop and food preparation tables, beer dispensing equipment, refrigerated and dry display cases, back bar, curved glass merchandisers, counter top refrigerators, and deli display cases.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/subzero.jpg" class="img-responsive" alt="Subzero-logo"></div>
              <div class="col-md-9 description" id="description">The world’s finest kitchens and most discerning people choose Sub-Zero and Wolf appliances. Why? No other brands offer such a powerful combination of performance, design and dependability. Owning our products assures that your food will always stay as fresh and flavorful as possible, and you’ll have the most precise, professional-grade instruments to cook it with, for delicious results every time.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/hobart.jpg" class="img-responsive" alt="Hobart-logo"></div>
              <div class="col-md-9 description" id="description">Now there is one destination for your commercial kitchen and grocery store equipment. Complementing our full line of food equipment—from flight-type warewashers to countertop food processors—Hobart also brings you premier refrigeration systems from Traulsen and proven bakery equipment from Baxter. All backed by the only manufacturer’s service organization in the industry with a national network of factory-trained technicians.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/true.jpg" class="img-responsive" alt="True-logo"></div>
              <div class="col-md-9 description" id="description">True Manufacturing is recognized as the leading manufacturer of commercial refrigerators and freezers in the world for the foodservice and soft drink industries. The path to that leadership position began in 1945, when Bob Trulaske and his father, Frank, and later his brother, Art, developed a refrigeration company in their house on Lenox Avenue in St. Louis.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/traulsen.jpg" class="img-responsive" alt="Traulsen-logo"></div>
              <div class="col-md-9 description" id="description">Trust. It comes from working with a company known worldwide for the quality of its equipment and the strength of its customer relationships. From the confidence that comes from knowing your food will be safe and tasty. From knowing you can count on Traulsen’s equipment and support for years and years to come. We’ve been in the business of building trust for 75 years. And we never stop.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/randell.jpg" class="img-responsive" alt="Randell-logo"></div>
              <div class="col-md-9 description" id="description">Unified Brand’s complete line of Randell commercial refrigerators, from our high performing standard models to our built-for-you custom models, are designed to help foodservice professionals do more than ever, whether it’s increasing shelf life, storing a wide variety of food products at once or expanding menus with more appealing choices to keep customers coming back.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 " id="logobox10"></div>
              <div class="col-md-9 description" id="description10"></div>
            </div>
          </div>
          
          <!-----------------------------------------------------------------------------------------------------------------------------------------
            ---------------------------------------------------------------------------------------------------------------------------------------->
          
          <div role="tabpanel" class="tab-pane" id="Plumbing">
            <div class="tab-container">
              <div class="col-md-3 thumbnail"><img src="logos/kohler.png" class="img-responsive" alt="Kohler-logo"></div>
              <div class="col-md-9 description" id="description">The Kohler corporation and each associate have the mission of contributing to a higher level of gracious living for those who are touched by our products and services. Gracious living is marked by qualities of charm, good taste and generosity of spirit. It is further characterized by self-fulfillment and the enhancement of nature.
                
                We reflect this mission in our work, in our team approach to meeting objectives and in each of the products and services we provide our customers.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/chicagofaucets.gif" class="img-responsive" alt="Chicago Faucets-logo"></div>
              <div class="col-md-9 description" id="description">Chicago Faucets has countless water conserving products for your facility. If you're curious
                how much you can save in switching from a 2.2 gpm faucet to a 1.5 gpm or a 0.5 gpm faucet, use our water saving calculator to get an estimate. It features estimated & sewer costs from major cities to also show you how upgrading your faucets can also provide a
                significant cost savings.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/aosmith.png" class="img-responsive" alt="AO Smith-logo"></div>
              <div class="col-md-9 description" id="description">A. O. Smith is about more than hot water. We recently entered the water purification industry to deliver clean water to consumers in China and other fast-growing parts of the world. It's all about water, and A. O. Smith has a singular focus on becoming a global leader in water technology.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/americanstandard.png" class="img-responsive" alt="American Standard-logo"></div>
              <div class="col-md-9 description" id="description">For over 140 years, American Standard has led the way in developing innovative bathroom and kitchen products including high performance toilets, stylish faucets, and wellness products that have set and re-set the standards for living healthy, living responsibly, and living beautifully.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/htp.gif" class="img-responsive" alt="HTP-logo"></div>
              <div class="col-md-9 description" id="description">HTP (Heat Transfer Products) is the industry leader in quality high efficiency boilers, indirects and water heaters for both commercial and residential applications. If you specify or install high-efficiency boilers and water heaters, you probably know about HTP's condensing boilers, with their fully modulating and load-matching, ultra-low-NOx burners that deliver AFUE ratings well in excess of 90%.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/moen.png" class="img-responsive" alt="Moen-logo"></div>
              <div class="col-md-9 description" id="description">From finishes that are guaranteed to last a lifetime, to faucets that perfectly balance your water pressure, Moen sets the standard for exceptional beauty and reliable, innovative design.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 thumbnail"><img src="logos/grohe.gif" class="img-responsive" alt="Grohe-logo"></div>
              <div class="col-md-9 description" id="description">Quality, technology, design and sustainability. Four brand values that illustrate our commitment to creating exceptional experiences. We set our standards extremely high to ensure that every time you turn on a GROHE faucet or step into a GROHE shower you can feel the difference.</div>
              <div class="manufacturer_divider"></div>
              <div class="col-md-3 " id="logobox10"></div>
              <div class="col-md-9 description" id="description10"></div>
            </div>
          </div>
        </div>
      </div>
      <!--/END TABS-->
      
      <div class="row clearfix manufacturer" style="background-color:none"></div>
      <p>&nbsp;</p>
      <h4>Call or contact us for more details about our fine heating and cooling products!</h4>
      <div class="panel panel-default">
        <div class="row clearfix"></div>
      </div>
      <div class="row clearfix"></div>
    </div>
    <div class="col-lg-3 col-lg-push-1">
        <div class="panel panel-primary">
          <div class="panel-heading">Online Scheduling & More</div>
          <div class="panel-body">
          <p> <img src="img/btn-go.png" name="scheduler_tile" align="left" id="scheduler_tile_l" style="cursor: pointer;"  onclick="javascript:window.open('//www.demandforced3.com/b/etile_scheduler_popup.jsp?d3cp_exid=acktempmechanicalservicesinc&d3cp_source=My%20Website','newwindow', 'width=790px, top=0, left=0, toolbar=no, menubar=no, scrollbars=1, resizable=1, location=no, status=0');" />All requests will be answered within one hour during business hours or by 9:00 a.m. on the next business day.</p>
  </div>
        </div>        <div class="panel panel-primary">
         <div class="panel-heading">Free Quotes and Estimates </div>
         <div class="panel-body"> Get a free quick quote or estimate anytime you have a heating or cooling need.
           <p></p>
           <p><img src="img/panel-img-sm-quote.jpg" class="img-responsive" alt="img"></p>
         </div>
         <div class="panel-footer"><a href="quotes-and-estimates.php" class="btn btn-primary" > Learn More</a></div>
       </div>        <div class="panel panel-primary">
         <div class="panel-heading">Customer Comments</div>
         <div class="panel-body">
           <p>
			Russ Ackerman's team is great. They installed a whole house humidifier . They were quick, clean and very professional even suggesting some very meaningful modifications. I would recommend them for any of your residential HVAC needs.<br><br>
				—Michael Meehan<br>           </p>
         </div>
         <div class="panel-footer"><a href="comments.php" class="btn btn-default" > See All Comments</a></div>
       </div>

    </div>
  </div>
  
  <!-- Site footer --></div>
<footer class="footer clearfix">
  <div class="container">
  	<div class="col-lg-4">
    <p><img src="img/logo-sm.png" width="286" height="54"></p>
    <p>805 OAKWOOD RD. SUITE B <br>
      LAKE ZURICH, ILLINOIS 60047</p>
    <p><strong style="font-size: 18px">847-719-2665</strong></p>
    <p>&nbsp;</p>
    <p>© Ack-Temp Mechanical Services Inc. 2024</p>
  	</div>
    <div class="col-lg-4"><p></p></div>
    <div class="col-lg-4"><p class="pull-right" style="margin-top:180px" >Site created by <a href="http://www.bizazz.com" target="_blank"><img src="img/logo-bizazz.png" width="80" alt="bizazz logo" /></a></p>
    <p></p></div>
  </div>
</footer><!-- /container --> 

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug --> 
<script src="js/ie10-viewport-bug-workaround.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<!-- Latest compiled and minified JavaScript --> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script> 
<script>
$('#myTabs a[href="#HVAC"]').tab('show') // Select tab by name
$('#myTabs a[href="#Refrigeration"]').tab('show') // Select tab by name
$('#myTabs a[href="#Plumbing"]').tab('show') // Select tab by name
</script>
</body>
</html>